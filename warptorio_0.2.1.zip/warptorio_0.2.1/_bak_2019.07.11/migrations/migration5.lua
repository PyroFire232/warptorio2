
	--****
global.warp_energy_research = 0
	
		game.players[1].print("Warptorio migration script applied")